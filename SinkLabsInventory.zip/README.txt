SinkLabs Inventory System (Basic v1)

SETUP INSTRUCTIONS:
---------------------
1. Go to https://script.google.com
2. Create a new project
3. Replace the default Code.gs with contents from the included Code.gs file
4. Add a new HTML file named 'Index' and paste in the content from Index.html
5. Save your project

6. Link this script to a Google Sheet with these columns in Row 1:
   Timestamp | Product Name | Category | Price | Quantity | Barcode | Image URL

7. To deploy the app:
   - Click "Deploy" > "New deployment"
   - Choose "Web app"
   - Set "Execute as": Me
   - Set "Who has access": Anyone
   - Click "Deploy" and authorize access
   - Use the generated URL to open your inventory app

Need help or custom development?
Email: hello@sinklabs.dev
